import SwiftUI

enum ExternalPalette {
    static let names = ["AZUL", "ROJO", "GRIS", "CAFÉ", "ROSA", "AMARILLO", "NARANJA", "NEGRO"]

    static func color(named name: String) -> Color {
        switch name {
        case "ROJO": return Color(red: 0.95, green: 0.12, blue: 0.16)
        case "GRIS": return Color(red: 0.62, green: 0.65, blue: 0.69)
        case "CAFÉ": return Color(red: 0.48, green: 0.29, blue: 0.17)
        case "ROSA": return Color(red: 0.96, green: 0.30, blue: 0.62)
        case "AMARILLO": return Color(red: 0.98, green: 0.78, blue: 0.12)
        case "NARANJA": return Color(red: 1.0, green: 0.43, blue: 0.08)
        case "NEGRO": return Color(red: 0.12, green: 0.12, blue: 0.14)
        default: return Color(red: 0.12, green: 0.55, blue: 0.98)
        }
    }
}

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @AppStorage("externalThemeColor") private var externalThemeColor = "AZUL"
    @State private var installedAppIcon: UIImage?

    private var installedAppDisplayName: String {
        let info = Bundle.main.infoDictionary ?? [:]
        for key in ["CFBundleDisplayName", "CFBundleName"] {
            if let value = info[key] as? String {
                let cleaned = value.trimmingCharacters(in: .whitespacesAndNewlines)
                if !cleaned.isEmpty { return cleaned }
            }
        }
        return "C3SAR EXTERNAL"
    }

    var body: some View {
        NavigationStack {
            ZStack {
                GeometryReader { proxy in
                    Image("SettingsSonicBackground")
                        .resizable()
                        .scaledToFill()
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .overlay(Color.black.opacity(0.48))
                }
                .ignoresSafeArea()

                Form {
                Section {
                    HStack(spacing: 14) {
                        Group {
                            if let installedAppIcon {
                                Image(uiImage: installedAppIcon)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 44, height: 44)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            } else {
                                AppLogo()
                            }
                        }

                        VStack(alignment: .leading, spacing: 3) {
                            Text(installedAppDisplayName).font(.headline)
                            Text(language.text("common.version", appVersion))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section(language.text("settings.language")) {
                    Picker(language.text("settings.language"), selection: $languageCode) {
                        ForEach(AppLanguage.allCases) { option in
                            Text(option.displayName).tag(option.rawValue)
                        }
                    }
                    .pickerStyle(.segmented)
                    .labelsHidden()
                }

                Section(language.text("common.device")) {
                    LabeledContent(language.text("dashboard.hardware_model"), value: AppInfo.displayMachineName)
                    LabeledContent(language.text("settings.ios_version"), value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                }

                Section {
                    HStack {
                        Text(language.text("settings.current_version"))
                        Spacer()
                        Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                        .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                    LabeledContent("iOS 17", value: ExploitSupportPolicy.verifiedIOS17Range)
                    LabeledContent("iOS 18", value: ExploitSupportPolicy.verifiedIOS18Range)
                    LabeledContent("iOS 26", value: ExploitSupportPolicy.verifiedIOS26Range)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("iOS 27.0")
                            .font(.body)
                        ForEach(ExploitSupportPolicy.verifiedIOS27Builds, id: \.build) { version in
                            Text(versionLabel(version))
                            .font(.caption.monospaced())
                            .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 2)
                } header: {
                    Text(language.text("settings.verified_versions"))
                } footer: {
                    Text(language.text("settings.supported_versions_footer"))
                }

                Section("SOCIAL MEDIA") {
                    creditsRow(
                        name: "Telegram",
                        role: "Únete al grupo de Lxz",
                        url: "https://t.me/Lxz_iOS"
                    )
                    Picker("COLORES", selection: $externalThemeColor) {
                        ForEach(ExternalPalette.names, id: \.self) { color in
                            Text(color).tag(color)
                        }
                    }
                    .pickerStyle(.navigationLink)
                }
                }
                .scrollContentBackground(.hidden)
                .background(Color.clear)
                .foregroundStyle(.white)
                .tint(Color.cyan)
                .listRowBackground(Color.black.opacity(0.68))
            }
            .navigationTitle(language.text("settings.title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(language.text("common.done")) { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
        .preferredColorScheme(.dark)
        .task {
            guard let bundleID = Bundle.main.bundleIdentifier, !bundleID.isEmpty else { return }
            let icon = await Task.detached(priority: .utility) {
                iconForBundleID(bundleID)
            }.value
            installedAppIcon = icon
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private func versionLabel(
        _ version: (beta: Int, publicBeta: Int?, build: String)
    ) -> String {
        if let publicBeta = version.publicBeta {
            return language.text(
                "settings.developer_public_beta_build",
                Int64(version.beta),
                Int64(publicBeta),
                version.build
            )
        }
        return language.text(
            "settings.developer_beta_build",
            Int64(version.beta),
            version.build
        )
    }

    @ViewBuilder
    private func creditsRow(name: String, role: String, url: String) -> some View {
        if let destination = URL(string: url) {
            Link(destination: destination) {
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(name)
                            .font(.headline)
                            .foregroundStyle(.primary)
                        Text(role)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "arrow.up.right")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(AppTheme.accent)
                        .frame(width: 28, height: 28)
                }
                .contentShape(Rectangle())
            }
            .accessibilityLabel(language.text("accessibility.open_profile", name))
        }
    }
}
